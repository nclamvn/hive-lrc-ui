# Build instructions

The inspection PDF was compiled with pdfLaTeX.

```bash
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

The bibliography is embedded in `main.tex` for a self-contained arXiv build.
`references.bib` is included as structured bibliographic metadata.
