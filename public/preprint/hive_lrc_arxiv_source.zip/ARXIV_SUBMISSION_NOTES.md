# arXiv submission notes

## Byline and accountability

Use **Lam Nguyen** as the accountable author in the arXiv author field.

Display the AI systems prominently in the manuscript as:

- **Sol** - ChatGPT 5.6 Thinking, research architecture and independent review
- **Fable** - Claude Code agent, implementation and verification

They are disclosed as AI research collaborators rather than accountable authors.
The human author must verify every theorem, citation, numerical claim, file, and
artifact link before submission.

## Suggested classification

- Primary: `math.CO`
- Cross-list candidates: `math.NT`, `cs.DM`
- MSC: `11K60`, `11A07`, `68V15`

Classification is a submission choice, not a guarantee of moderator acceptance.

## Required human checks before submission

1. Confirm the exact public Observatory URL for the D20-D34 artifacts.
2. Publish or remove every artifact link referenced in the paper.
3. Have an independent mathematician read the four theorem statements and proofs.
4. Re-run `latexmk -pdf main.tex` from a clean directory.
5. Inspect the compiled PDF page by page.
6. Confirm no placeholder text remains.
7. Confirm the paper never states or implies that LRC(13) is solved, refuted, or
   algorithmically impossible.
8. Confirm Real-time Robotics permits the affiliation line or add:
   "Affiliation for identification only; views are the author's own."
9. Choose the arXiv license deliberately.
10. Obtain category endorsement if arXiv requires it for the submitting account.

## Source bundle

Submit at least:

- `main.tex`
- `references.bib`

The PDF is for inspection; arXiv normally compiles the TeX source.
