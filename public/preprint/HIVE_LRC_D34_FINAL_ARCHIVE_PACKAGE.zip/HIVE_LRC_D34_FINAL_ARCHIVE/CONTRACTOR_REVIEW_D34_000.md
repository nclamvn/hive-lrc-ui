# Contractor Review — TIP-D34-000

## Official verdict

- TIP-D34-000: ACCEPTED WITH SCOPE CORRECTIONS
- D34 disposition: ARCHIVE-WITHOUT-TERMINAL-THEOREM
- Active campaign: HALTED
- Full architecture family: OPEN
- Theory-Survivor: NOT CERTIFIED
- Campaign authorization: NO
- BASE-SURVIVOR: NONE
- GLOBAL-WITNESS: NONE
- LRC(13): OPEN
- Evidence ceiling: I2

## Mandatory corrections

### R15 — Coppersmith is a subroute, not all lattice/CVP

For the univariate polynomial `f(y)=y^2-r`, standard small-root reasoning reaches the range `|y| < M^(1/2)`.

For Q13:
- if `M >= B13^2`, every governed `y < B13` lies in that range;
- but this is already the no-wrap / regime-C zone, where exact q-scan has constant-size candidate range.

Therefore the standard univariate Coppersmith subroute adds no earlier leverage.

This does not close:
- exact CVP with known factorization;
- higher-dimensional embeddings;
- bounded-distance formulations;
- proof-producing lattice enumeration;
- other lattice-assisted exact methods in `B13 < M < B13^2`.

R15 remains `ARCHIVE-OPEN`, not `REFUTED`.

### R14 — monomial count does not prove cap failure

A dense polynomial of total degree 13 in 13 variables has

`binomial(26,13) = 10,400,600`

monomials, approximately `2^23.31`, not more than `2^42`.

At 1,935 bits per coefficient, the raw coefficient payload would be approximately 2.34 GiB before object, indexing, and elimination overhead. This may be impractical, but it is not an exact cap obstruction.

Resultant and elimination routes may still suffer severe degree and height growth, but closure requires a concrete elimination formulation and a certified bound.

R14 remains `ARCHIVE-OPEN / LOW-PRIORITY`, not theorem-refuted.

## Why archive is still accepted

The archive verdict is accepted as a research-disposition decision because:

1. no candidate passed the declared continuation rubric;
2. no bounded first gate was shown to have both campaign leverage and decisive falsifiability;
3. the implemented program has produced a coherent retained corpus;
4. continued work would be speculative rather than gate-driven.

This is not a terminal architecture theorem.
