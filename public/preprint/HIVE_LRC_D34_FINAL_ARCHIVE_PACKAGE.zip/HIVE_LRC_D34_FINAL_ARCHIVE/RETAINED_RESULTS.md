# Retained Results

## Mathematical results

1. **C0 local-content reduction**
   - Folded local cover, squared multiset, split polynomial, and full elementary-symmetric coefficient vector encode the same local orbit content in the accepted scope.

2. **Q13 theorem bundle**
   - Soundness.
   - One-global-scale semantics.
   - Modular-root structure.
   - Corrected distinct-residue non-vacuity theorem.

3. **D31 top-residue coset theorem**
   - Nonzero admissible top-coefficient residues form unions of 26th-power cosets.
   - Zero is a separate orbit.

4. **D32 local symbolic-separability theorem**
   - Independent local relations have additive symbolic construction size under the declared product-compatible ordering and local-size assumptions.

## Exact algorithmic result

5. **D30 certified hybrid Q13 evaluator**
   - Exact enumeration.
   - Exact meet-in-the-middle.
   - Exact q-scan.
   - Deterministic preflight dispatcher.
   - Honest `OPEN-INCOMPLETE` behavior outside the certified envelope.

## Scoped negative-capability result

Within the implemented subset of the declared architecture family and under the frozen caps, no implemented path produced a cap-fitting complete n=13 campaign.

Every obstruction remains scoped to its theorem, representation, encoding, variable order, cut language, or implementation.
