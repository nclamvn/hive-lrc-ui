# Open Routes and Reopen Triggers

## Routes preserved as open

### R14 — Algebraic / resultant

Status: `ARCHIVE-OPEN / LOW-PRIORITY`

Reopen only if a proposal supplies:
- the exact elimination object;
- degree and coefficient-height bounds;
- one-global-scale and primitivity preservation;
- replayable EMPTY certificate semantics;
- a complete small-domain falsification test;
- a first gate inside frozen caps.

### R15 — Lattice / exact CVP

Status: `ARCHIVE-OPEN`

The standard univariate small-root subroute is subsumed by q-scan in regime C, but general exact lattice/CVP formulations remain open.

Reopen only if a proposal supplies:
- an exact lattice and target;
- a completeness theorem;
- independently replayable EMPTY certificates;
- a reason it acts in `B13 < M < B13^2`;
- a bounded decisive pilot.

## General reopen triggers

The archive may be reopened if at least one of the following appears:

1. A new sound cross-prime predicate with useful pruning before the Q13 onset.
2. A proof-producing exact bounded modular-square-root algorithm that fits the useful R2 regime.
3. A symbolic compiler with a certified non-Cartesian construction bound for the frozen LRC relation family.
4. A concrete algebraic elimination route with certified degree/height and proof-artifact bounds.
5. A lattice/CVP formulation with authoritative EMPTY certificates above the standard `M^(1/2)` small-root range.
6. A theorem that closes one of the open representation or proof-complexity questions.
